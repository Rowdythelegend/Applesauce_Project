import React from 'react';
import { LearningProgress } from '../types';

interface LearningProgressDisplayProps {
  progress: LearningProgress;
  onClose: () => void;
}

const LearningProgressDisplay: React.FC<LearningProgressDisplayProps> = ({ progress, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 animate-fade-in">
      <div className="bg-gradient-to-br from-indigo-100 to-blue-200 rounded-xl shadow-2xl p-6 w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col relative transform scale-95 animate-scale-in">
        <h2 className="text-3xl font-extrabold text-indigo-800 mb-4 border-b-2 border-indigo-300 pb-2 flex items-center gap-2">
          <span role="img" aria-label="Rocket">🚀</span> Applesauce's Discovery Log!
        </h2>

        <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
          {progress.topicsCovered.length === 0 ? (
            <p className="text-indigo-700 text-lg italic text-center py-8">
              No topics explored yet! Start chatting with The Clairvoyant to fill your log! ✨
            </p>
          ) : (
            <ul className="list-none space-y-3 pl-0">
              {progress.topicsCovered.map((topic, index) => (
                <li
                  key={index}
                  className="bg-white bg-opacity-80 p-3 rounded-lg shadow-sm flex items-center gap-3 text-indigo-900 text-base"
                >
                  <span className="text-indigo-500 font-bold">#{index + 1}</span>
                  <span className="text-lg font-medium">{topic}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <button
          onClick={onClose}
          className="mt-6 w-full py-3 bg-indigo-600 text-white font-bold rounded-lg shadow-lg hover:bg-indigo-700 transition-colors duration-300 active:bg-indigo-800"
          aria-label="Close learning progress display"
        >
          Close Log
        </button>
      </div>
    </div>
  );
};

export default LearningProgressDisplay;